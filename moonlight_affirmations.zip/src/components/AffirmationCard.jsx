import React from 'react'

export default function AffirmationCard({ affirmation, onPlay, onShare, onToggleFav, isFav, onRemove }) {
  return (
    <div className="p-3 bg-[rgba(255,255,255,0.03)] backdrop-blur rounded-2xl flex items-start justify-between border border-[rgba(255,255,255,0.04)]">
      <div className="flex-1 cursor-pointer" onClick={() => {}}>
        <div className="font-medium text-white">{affirmation.text}</div>
        <div className="text-xs text-slate-300">{affirmation.category}</div>
      </div>
      <div className="ml-3 flex items-center gap-1">
        <button onClick={() => onPlay(affirmation)}>🔊</button>
        <button onClick={() => onShare(affirmation)}>🔗</button>
        <button onClick={() => onToggleFav(affirmation.id)} className="text-yellow-300">{isFav ? '★' : '☆'}</button>
        <button onClick={() => onRemove(affirmation.id)} className="text-red-400">✕</button>
      </div>
    </div>
  )
}
