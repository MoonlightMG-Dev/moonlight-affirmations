export const DEFAULT_AFFIRMATIONS = [
  { id: 1, text: "I am guided by the gentle light within me.", category: 'Inner Light' },
  { id: 2, text: "Calmness and clarity flow through me like moonlight.", category: 'Calm' },
  { id: 3, text: "I create space for abundance and peace.", category: 'Abundance' },
  { id: 4, text: "I trust the rhythm of my own journey.", category: 'Trust' },
  { id: 5, text: "Each breath grounds me and opens my heart.", category: 'Grounding' },
  { id: 6, text: "I shine softly but powerfully in my truth.", category: 'Self-Worth' },
];
