import React, { useEffect, useMemo, useState } from 'react'
import AffirmationCard from './components/AffirmationCard'
import { DEFAULT_AFFIRMATIONS } from './data/defaultAffirmations'

const STORAGE_KEYS = {
  AFFS: 'moon_affirm_affirmations_v1',
  FAVS: 'moon_affirm_favs_v1',
  SETTINGS: 'moon_affirm_settings_v1',
}

export default function App() {
  const [affirmations, setAffirmations] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.AFFS)) || DEFAULT_AFFIRMATIONS } catch { return DEFAULT_AFFIRMATIONS }
  })
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.FAVS)) || [] } catch { return [] }
  })
  const [current, setCurrent] = useState(null)
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All')
  const [newAffText, setNewAffText] = useState('')
  const [settings, setSettings] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.SETTINGS)) || {} } catch { return {} }
  })

  useEffect(() => localStorage.setItem(STORAGE_KEYS.AFFS, JSON.stringify(affirmations)), [affirmations])
  useEffect(() => localStorage.setItem(STORAGE_KEYS.FAVS, JSON.stringify(favorites)), [favorites])
  useEffect(() => localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings)), [settings])

  useEffect(() => { if (!current && affirmations.length) setCurrent(affirmations[0]) }, [])

  const categories = useMemo(() => ['All', ...Array.from(new Set(affirmations.map(a => a.category || 'General')))], [affirmations])

  const filtered = useMemo(() => affirmations.filter(a => {
    if (category !== 'All' && a.category !== category) return false
    if (!query) return true
    return a.text.toLowerCase().includes(query.toLowerCase())
  }), [affirmations, category, query])

  function speak(text) {
    if (!('speechSynthesis' in window)) return alert('Speech synthesis not supported in this browser.')
    const u = new SpeechSynthesisUtterance(text)
    if (settings.rate) u.rate = settings.rate
    window.speechSynthesis.cancel(); window.speechSynthesis.speak(u)
  }

  function toggleFavorite(id) { setFavorites(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]) }

  function addAffirmation() {
    const t = newAffText.trim(); if (!t) return
    const newAff = { id: Date.now(), text: t, category: settings.newCategory || 'Personal' }
    setAffirmations(prev => [newAff, ...prev]); setNewAffText(''); setCategory(newAff.category); setCurrent(newAff)
  }

  function removeAffirmation(id) { if (!confirm('Remove this affirmation?')) return; setAffirmations(prev => prev.filter(a => a.id !== id)); setFavorites(prev => prev.filter(x => x !== id)); if (current?.id === id) setCurrent(null) }

  function exportJSON() {
    const data = JSON.stringify({ affirmations, favorites }, null, 2)
    const blob = new Blob([data], { type: 'application/json' }); const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'moon_affirm_export.json'; a.click(); URL.revokeObjectURL(url)
  }

  function importJSON(file) {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const obj = JSON.parse(e.target.result)
        if (obj.affirmations) setAffirmations(obj.affirmations)
        if (obj.favorites) setFavorites(obj.favorites)
        alert('Import complete.')
      } catch { alert('Invalid JSON file.') }
    }
    reader.readAsText(file)
  }

  function requestNotificationPermission() { if (!('Notification' in window)) return alert('This browser does not support notifications.'); Notification.requestPermission().then(p => alert('Notification permission: ' + p)) }
  function scheduleBrowserNotification(secondsFromNow = 10) { if (Notification.permission !== 'granted') return alert('Please enable notifications first.'); const aff = current || affirmations[Math.floor(Math.random() * affirmations.length)]; setTimeout(() => new Notification('Moonlight Affirmation', { body: aff.text }), secondsFromNow * 1000); alert(`Scheduled notification in ${secondsFromNow} seconds.`) }

  return (
    <div className="min-h-screen p-6 text-white" style={{ background: 'linear-gradient(180deg,#070617 0%, #0b1020 100%)' }}>
      <div className="max-w-4xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-3">
              <img src="/src/assets/logo.svg" alt="Moonlight Affirmations" style={{ width:48, height:48 }} />
              <div>
                <h1 className="text-3xl font-extrabold">Moonlight Affirmations</h1>
                <p className="text-sm text-slate-300">Illuminate Your Mind, One Affirmation at a Time</p>
              </div>
            </div>
          </div>
          <div className="space-x-2">
            <button onClick={() => { setQuery(''); setCategory('All'); }} className="px-3 py-1 rounded bg-[rgba(255,255,255,0.04)]">Reset</button>
            <button onClick={() => { const idx = Math.floor(Math.random() * filtered.length); setCurrent(filtered[idx]) }} className="px-3 py-1 rounded bg-[rgba(255,255,255,0.04)]">Shuffle</button>
          </div>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <section className="md:col-span-2">
            <div className="p-4 rounded-3xl" style={{ background: 'linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', boxShadow: '0 8px 30px rgba(99,102,241,0.08)' }}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs text-slate-400">Category</div>
                  <select value={category} onChange={e => setCategory(e.target.value)} className="mt-1 bg-transparent p-2 rounded border border-[rgba(255,255,255,0.04)]">
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="w-1/2">
                  <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search affirmations..." className="w-full p-2 rounded border border-[rgba(255,255,255,0.04)] bg-transparent"/>
                </div>
              </div>

              <div className="mt-6">
                {current ? (
                  <div className="p-6 rounded-2xl" style={{ background: 'linear-gradient(90deg, rgba(167,139,250,0.06), rgba(107,122,213,0.04))', boxShadow: '0 12px 40px rgba(88,99,201,0.06)' }}>
                    <div className="flex justify-between items-start">
                      <h2 className="text-xl font-semibold">{current.text}</h2>
                      <div className="space-x-2">
                        <button onClick={() => speak(current.text)} className="px-3 py-1 rounded bg-[rgba(167,139,250,0.12)]">Play</button>
                        <button onClick={() => navigator.clipboard.writeText(`Affirmation: \"${current.text}\"`).then(() => alert('Copied'))} className="px-3 py-1 rounded bg-[rgba(154,230,180,0.06)]">Share</button>
                        <button onClick={() => toggleFavorite(current.id)} className="px-3 py-1 rounded bg-[rgba(250,204,21,0.06)]">{favorites.includes(current.id) ? 'Unfav' : 'Fav'}</button>
                      </div>
                    </div>
                    <div className="mt-3 text-sm text-slate-300">Category: {current.category}</div>
                  </div>
                ) : (
                  <div className="p-6 rounded-2xl text-slate-400">No affirmation selected.</div>
                )}
              </div>

              <div className="mt-6 grid gap-3">
                {filtered.map(a => (
                  <AffirmationCard
                    key={a.id}
                    affirmation={a}
                    onPlay={() => speak(a.text)}
                    onShare={() => navigator.clipboard.writeText(a.text).then(() => alert('Copied'))}
                    onToggleFav={() => toggleFavorite(a.id)}
                    isFav={favorites.includes(a.id)}
                    onRemove={() => removeAffirmation(a.id)}
                  />
                ))}
              </div>

              <div className="mt-4 flex gap-2">
                <input value={newAffText} onChange={e => setNewAffText(e.target.value)} placeholder="Write a new affirmation" className="flex-1 p-2 rounded bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.04)]" />
                <input placeholder="Category" onChange={e => setSettings(s => ({ ...s, newCategory: e.target.value }))} className="w-36 p-2 rounded bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.04)]" />
                <button onClick={addAffirmation} className="px-4 py-2 rounded bg-[rgba(167,139,250,0.16)]">Add</button>
              </div>

            </div>
          </section>

          <aside>
            <div className="p-4 rounded-3xl" style={{ background: 'rgba(255,255,255,0.02)' }}>
              <div className="mb-3 font-semibold">Favorites</div>
              <div className="space-y-2">
                {favorites.length === 0 && <div className="text-slate-400">No favorites yet.</div>}
                {favorites.map(id => {
                  const a = affirmations.find(x => x.id === id)
                  if (!a) return null
                  return (
                    <div key={id} className="flex items-center justify-between p-2 rounded">
                      <div className="text-sm cursor-pointer" onClick={() => setCurrent(a)}>{a.text}</div>
                      <div className="space-x-1">
                        <button onClick={() => speak(a.text)}>🔊</button>
                        <button onClick={() => toggleFavorite(id)}>—</button>
                      </div>
                    </div>
                  )
                })}
              </div>

              <hr className="my-3 border-[rgba(255,255,255,0.03)]" />
              <div className="space-y-2 text-sm">
                <div>
                  <button onClick={() => { requestNotificationPermission(); }} className="w-full p-2 rounded bg-[rgba(255,255,255,0.02)]">Enable Notifications</button>
                </div>
                <div>
                  <button onClick={() => scheduleBrowserNotification(10)} className="w-full p-2 rounded bg-[rgba(255,255,255,0.02)]">Notify in 10s</button>
                </div>
                <div className="flex gap-2">
                  <label className="flex-1 p-2 rounded bg-[rgba(255,255,255,0.02)] text-center cursor-pointer">
                    <input type="file" className="hidden" onChange={e => importJSON(e.target.files[0])} />Import
                  </label>
                  <button onClick={exportJSON} className="flex-1 p-2 rounded bg-[rgba(255,255,255,0.02)]">Export</button>
                </div>
              </div>

            </div>

            <div className="mt-4 p-4 rounded-3xl" style={{ background: 'rgba(255,255,255,0.02)' }}>
              <div className="font-semibold mb-2">Settings</div>
              <div className="text-sm space-y-2">
                <div>
                  <label className="block text-xs">Speech rate (0.5 - 2)</label>
                  <input type="range" min="0.5" max="2" step="0.1" value={settings.rate || 1} onChange={e => setSettings(s => ({ ...s, rate: Number(e.target.value) }))} />
                </div>
                <div>
                  <button onClick={() => { setAffirmations(DEFAULT_AFFIRMATIONS); setFavorites([]); alert('Reset to defaults'); }} className="p-2 rounded w-full">Reset to defaults</button>
                </div>
              </div>
            </div>

          </aside>

        </main>

        <footer className="mt-8 text-center text-sm text-slate-400">Made with 🌙 — Moonlight Affirmations</footer>
      </div>
    </div>
  )
}
